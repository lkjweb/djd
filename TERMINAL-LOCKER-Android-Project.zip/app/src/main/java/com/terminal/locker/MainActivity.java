package com.terminal.locker;

import android.app.Activity;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.*;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(4, 10, 7);
    private final int GREEN = Color.rgb(57, 255, 136);
    private TextView timerText, statusText;
    private EditText pinInput;
    private CountDownTimer timer;
    private long remaining = 5 * 60 * 1000L;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        buildScreen();
    }

    private TextView text(String value, int size) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextColor(GREEN); t.setTextSize(size);
        t.setTypeface(Typeface.MONOSPACE); t.setGravity(Gravity.CENTER);
        return t;
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(24, 24, 24, 24);
        root.setBackgroundColor(BG);

        TextView title = text("TERMINAL LOCKER", 25);
        root.addView(title, new LinearLayout.LayoutParams(-1, 64));
        root.addView(text("> SESSION INITIALIZED", 14));
        root.addView(text("> LOCAL DEMO MODE", 14));

        TextView line = text("--------------------------------", 14);
        root.addView(line);

        timerText = text("05:00", 42);
        root.addView(timerText, new LinearLayout.LayoutParams(-1, 90));

        statusText = text("STATUS: SIMULATION ACTIVE", 14);
        root.addView(statusText);

        TextView info = text("This is a visual demo only.\nIt does not block Android or other apps.", 13);
        info.setPadding(0, 18, 0, 18);
        root.addView(info);

        pinInput = new EditText(this);
        pinInput.setSingleLine(true);
        pinInput.setHint("ENTER DEMO PIN");
        pinInput.setHintTextColor(Color.GRAY);
        pinInput.setTextColor(GREEN);
        pinInput.setGravity(Gravity.CENTER);
        pinInput.setTypeface(Typeface.MONOSPACE);
        pinInput.setInputType(2);
        root.addView(pinInput, new LinearLayout.LayoutParams(-1, 54));

        Button unlock = button("UNLOCK DEMO");
        unlock.setOnClickListener(v -> {
            if ("1234".contentEquals(pinInput.getText())) {
                stopTimer();
                statusText.setText("STATUS: DEMO UNLOCKED");
                timerText.setText("ACCESS OK");
            } else {
                statusText.setText("ERROR: INCORRECT PIN (DEMO: 1234)");
            }
        });
        root.addView(unlock, new LinearLayout.LayoutParams(-1, 54));

        Button exit = button("EXIT APP");
        exit.setOnClickListener(v -> finish());
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(-1, 54);
        ep.topMargin = 10;
        root.addView(exit, ep);

        setContentView(root);
        startTimer();
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label); b.setTextColor(GREEN);
        b.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(14, 35, 23)));
        return b;
    }

    private void startTimer() {
        timer = new CountDownTimer(remaining, 1000) {
            public void onTick(long millis) {
                remaining = millis;
                timerText.setText(String.format("%02d:%02d", millis / 60000, (millis % 60000) / 1000));
            }
            public void onFinish() {
                timerText.setText("00:00");
                statusText.setText("STATUS: TIMER COMPLETE");
            }
        }.start();
    }

    private void stopTimer() {
        if (timer != null) timer.cancel();
    }

    @Override protected void onDestroy() {
        stopTimer();
        super.onDestroy();
    }
}
